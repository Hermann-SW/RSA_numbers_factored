#define EXTERNC		extern "C"
#define FALSE 0
#define TRUE 1
#define stopCheck escapeCheck
int stopCheck (void);
#include <ctype.h>
#include "gwnum.h"
#include "..\giants.c"
