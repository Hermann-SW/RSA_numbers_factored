//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Prime95.rc
//
#define IDOK2                           3
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_PRIME9TYPE                  129
#define IDD_RANGE                       130
#define IDD_NEXTRANGE                   131
#define IDD_TEST                        132
#define IDD_CPU                         133
#define IDC_CURSOR1                     133
#define IDD_TIME                        134
#define IDD_PREFERENCES                 135
#define IDC_CURSOR2                     135
#define IDD_PRIMENET                    145
#define IDD_PRIORITY                    146
#define IDD_AFFINITY                    151
#define IDI_YELLOW_ICON                 153
#define IDD_CONTENTS                    155
#define IDR_TRAYMENU                    159
#define IDC_CURSOR3                     160
#define IDC_CHECK1                      1000
#define IDC_NOISE                       1000
#define IDC_EDIT1                       1001
#define IDC_BACKUP                      1001
#define IDC_EXPR                        1001
#define IDC_B2                          1002
#define IDC_BATTERY                     1002
#define IDC_HELP_TEXT                   1002
#define IDC_CUMULATIVE                  1003
#define IDC_P                           1005
#define IDC_B1                          1006
#define IDC_DISK                        1006
#define IDC_HOURS                       1006
#define IDC_PGEN_OUTPUT                 1006
#define IDC_P2                          1007
#define IDC_NETWORK                     1007
#define IDC_PGEN_LINE                   1007
#define IDC_WORK                        1008
#define IDC_R_ITER                      1008
#define IDC_START_TIME                  1008
#define IDC_EXPRFILE                    1008
#define IDC_P1                          1009
#define IDC_WORK2                       1009
#define IDC_EXPRFILE_LINE               1009
#define IDC_NAME                        1013
#define IDC_TEST                        1019
#define IDC_WORK_DFLT                   1022
#define IDC_WORKGROUP                   1023
#define IDC_NETWORK_TEXT                1024
#define IDC_WORK_DFLT2                  1024
#define IDC_WORKGROUP2                  1025
#define IDC_PRIORITY                    1029
#define IDC_COMPLETION                  1029
#define IDC_LINE1                       1030
#define IDC_AFFINITY                    1030
#define IDC_LINE2                       1031
#define IDC_LINE3                       1032
#define IDC_AFFINITY_TEXT               1038
#define IDC_TEAM                        1038
#define IDC_ALL_CPUS                    1039
#define IDC_NAME_TEXT                   1044
#define IDC_ID_TEXT                     1045
#define IDC_PWD_TEXT                    1046
#define IDC_WORK_PGEN                   1050
#define IDC_WORK_EXPRFILE               1051
#define IDC_WORK_EXPR                   1052
#define IDC_PGEN_INPUT                  1053
#define IDS_PGEN_OUTPUT                 1054
#define IDS_PGEN_INPUT                  1055
#define IDS_PGEN_LINE                   1056
#define IDC_CPU_INFO                    1056
#define IDS_EXPRFILE                    1057
#define IDS_EXPRFILE_LINE               1058
#define IDM_CONTINUE                    32771
#define IDM_STOP                        32772
#define IDM_ERRCHK                      32773
#define IDM_AUTO                        32774
#define IDM_RANGE                       32775
#define IDM_TEST                        32777
#define IDM_PREFERENCES                 32781
#define IDM_CPU                         32782
#define ID_RANGE_STATUS                 32783
#define IDM_TRAY_OPEN                   32784
#define IDM_TRAY                        32788
#define IDM_HIDE                        32789
#define IDM_PRIORITY                    32793
#define IDM_QUIT                        32795
#define IDM_SERVICE                     32797
#define ID_MANUALCOMM                   32798
#define IDM_AFFINITY                    32800
#define USR_SERVICE_STOP                32801
#define ID_HELP_CONTENTS                32802

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        161
#define _APS_NEXT_COMMAND_VALUE         32803
#define _APS_NEXT_CONTROL_VALUE         1060
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
