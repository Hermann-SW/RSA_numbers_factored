/* Common definitions in Prime95, Saver95, and NTPrime */

extern HANDLE WORKER_THREAD;

int isWindows95 ();
int isWindows2000 ();

/* No OS specific tasks to execute */

#define doMiscTasks()

